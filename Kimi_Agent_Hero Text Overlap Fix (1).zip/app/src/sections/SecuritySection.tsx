import { useEffect, useRef, useState } from 'react';
import { Shield, Lock, FileCheck, Server, Key, Eye } from 'lucide-react';

const securityFeatures = [
  {
    icon: Shield,
    title: 'Enterprise-grade access',
    description: 'SSO, SCIM, and role-based permissions. Control who can access what with granular permissions that scale with your organization.',
    visual: 'access'
  },
  {
    icon: Lock,
    title: 'Data stays yours',
    description: 'No training on your data. Retention policies you control. Your information is never used to improve our models.',
    visual: 'data'
  },
  {
    icon: FileCheck,
    title: 'Audit-ready',
    description: 'Logs, exports, and compliance helpers built in. Generate reports for audits with a single click.',
    visual: 'audit'
  }
];

const SecuritySection = () => {
  const [visibleItems, setVisibleItems] = useState<boolean[]>([false, false, false]);
  const sectionRef = useRef<HTMLDivElement>(null);
  const itemsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observers: IntersectionObserver[] = [];

    itemsRef.current.forEach((item, index) => {
      if (item) {
        const observer = new IntersectionObserver(
          ([entry]) => {
            if (entry.isIntersecting) {
              setVisibleItems(prev => {
                const newState = [...prev];
                newState[index] = true;
                return newState;
              });
              observer.disconnect();
            }
          },
          { threshold: 0.2 }
        );
        observer.observe(item);
        observers.push(observer);
      }
    });

    return () => observers.forEach(obs => obs.disconnect());
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="security"
      className="relative z-50 py-24 lg:py-32"
    >
      <div className="px-6 lg:px-[7vw]">
        {/* Header */}
        <div className="text-center mb-20">
          <h2 
            className="text-[clamp(32px,3.6vw,52px)] font-bold text-[#F4F6FF] mb-6"
            style={{ fontFamily: 'Sora, sans-serif' }}
          >
            Built for security & scale
          </h2>
          <p className="text-[#A6AFC8] text-lg max-w-2xl mx-auto">
            Enterprise controls, clear data policies, and compliance built in.
          </p>
        </div>

        {/* Feature Rows */}
        <div className="space-y-16 lg:space-y-24 max-w-6xl mx-auto">
          {securityFeatures.map((feature, index) => (
            <div
              key={feature.title}
              ref={el => { itemsRef.current[index] = el; }}
              className={`flex flex-col ${
                index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
              } items-center gap-10 lg:gap-16 transition-all duration-700 ${
                visibleItems[index] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              {/* Text Content */}
              <div className="flex-1">
                <div className="w-12 h-12 rounded-xl bg-[#4C6EF5]/10 flex items-center justify-center mb-6">
                  <feature.icon size={24} className="text-[#4C6EF5]" />
                </div>
                <h3 
                  className="text-2xl lg:text-3xl font-bold text-[#F4F6FF] mb-4"
                  style={{ fontFamily: 'Sora, sans-serif' }}
                >
                  {feature.title}
                </h3>
                <p className="text-[#A6AFC8] text-lg leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {/* Visual Card */}
              <div className="flex-1 w-full">
                <div className="glass-card p-8 aspect-[4/3] flex items-center justify-center relative overflow-hidden">
                  {/* Decorative elements based on feature */}
                  {feature.visual === 'access' && (
                    <div className="relative w-full h-full flex items-center justify-center">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-32 h-32 rounded-full border border-[#4C6EF5]/20" />
                        <div className="absolute w-48 h-48 rounded-full border border-[#4C6EF5]/10" />
                      </div>
                      <div className="relative z-10 flex flex-col items-center gap-4">
                        <div className="w-16 h-16 rounded-2xl bg-[#4C6EF5]/20 flex items-center justify-center">
                          <Key size={28} className="text-[#4C6EF5]" />
                        </div>
                        <div className="flex gap-2">
                          <span className="px-3 py-1 rounded-full bg-[#4C6EF5]/20 text-[#4C6EF5] text-xs">SSO</span>
                          <span className="px-3 py-1 rounded-full bg-[#4C6EF5]/20 text-[#4C6EF5] text-xs">SCIM</span>
                          <span className="px-3 py-1 rounded-full bg-[#4C6EF5]/20 text-[#4C6EF5] text-xs">RBAC</span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {feature.visual === 'data' && (
                    <div className="relative w-full h-full flex items-center justify-center">
                      <div className="grid grid-cols-3 gap-3">
                        {[...Array(9)].map((_, i) => (
                          <div 
                            key={i} 
                            className={`w-10 h-10 rounded-lg ${
                              i === 4 ? 'bg-[#4C6EF5]' : 'bg-white/5'
                            } flex items-center justify-center`}
                          >
                            {i === 4 && <Lock size={16} className="text-white" />}
                          </div>
                        ))}
                      </div>
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="flex items-center gap-2 text-xs text-[#A6AFC8]">
                          <Eye size={14} />
                          <span>Zero data retention</span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {feature.visual === 'audit' && (
                    <div className="relative w-full h-full flex flex-col items-center justify-center">
                      <div className="w-full max-w-xs space-y-3">
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
                          <FileCheck size={18} className="text-[#4C6EF5]" />
                          <span className="text-sm text-[#F4F6FF]">Activity logs</span>
                          <span className="ml-auto text-xs text-[#A6AFC8]">24h</span>
                        </div>
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
                          <Server size={18} className="text-[#4C6EF5]" />
                          <span className="text-sm text-[#F4F6FF]">Data exports</span>
                          <span className="ml-auto text-xs text-[#A6AFC8]">Ready</span>
                        </div>
                        <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
                          <Shield size={18} className="text-[#4C6EF5]" />
                          <span className="text-sm text-[#F4F6FF]">Compliance report</span>
                          <span className="ml-auto text-xs text-green-400">✓</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SecuritySection;
