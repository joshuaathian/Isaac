import { useEffect, useRef, useState } from 'react';
import { Inbox, Calendar, FileText, Users, CheckCircle2, ArrowRight } from 'lucide-react';

const sidebarItems = [
  { icon: Inbox, label: 'Inbox', active: true },
  { icon: Calendar, label: 'Schedule', active: false },
  { icon: FileText, label: 'Briefs', active: false },
  { icon: Users, label: 'Contacts', active: false },
];

const taskItems = [
  { title: 'Prep brief for Q3 planning', status: 'pending', time: 'Due in 2h' },
  { title: 'Reschedule design review', status: 'completed', time: 'Done' },
  { title: 'Send follow-up to Legal', status: 'pending', time: 'Due tomorrow' },
  { title: 'Research competitor pricing', status: 'in-progress', time: 'In progress' },
];

const DashboardSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="dashboard"
      className="section-pinned flex items-center z-30"
    >
      <div className="relative w-full h-full">
        {/* Left Headline Block */}
        <div 
          className={`absolute transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
          }`}
          style={{ 
            left: '7vw',
            top: '14vh',
            width: '30vw'
          }}
        >
          <h2 
            className="text-[clamp(32px,3.6vw,52px)] font-bold text-[#F4F6FF] mb-6"
            style={{ fontFamily: 'Sora, sans-serif' }}
          >
            Isaac at work
          </h2>
          <p className="text-[#A6AFC8] text-lg leading-relaxed mb-8">
            A simple dashboard. Clear next steps. No noise.
          </p>
          <button className="flex items-center gap-2 text-[#4C6EF5] hover:text-[#5c7cf7] transition-colors group">
            See how it works
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Dashboard Card */}
        <div 
          className={`glass-card absolute overflow-hidden transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-16'
          }`}
          style={{ 
            left: '44vw',
            top: '16vh',
            width: '49vw',
            height: '68vh',
            minWidth: '400px',
            transitionDelay: '0.2s'
          }}
        >
          {/* Dashboard Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#4C6EF5]/20 flex items-center justify-center">
                <span className="text-[#4C6EF5] font-semibold text-sm">I</span>
              </div>
              <span className="text-[#F4F6FF] font-medium">Isaac</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#4C6EF5] animate-pulse" />
              <span className="text-xs text-[#A6AFC8]">Active</span>
            </div>
          </div>

          {/* Dashboard Content */}
          <div className="flex h-[calc(100%-60px)]">
            {/* Sidebar */}
            <div className="w-48 border-r border-white/5 p-4">
              {sidebarItems.map((item) => (
                <div 
                  key={item.label}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 cursor-pointer transition-colors ${
                    item.active 
                      ? 'bg-[#4C6EF5]/10 text-[#F4F6FF]' 
                      : 'text-[#A6AFC8] hover:text-[#F4F6FF] hover:bg-white/5'
                  }`}
                >
                  <item.icon size={18} />
                  <span className="text-sm">{item.label}</span>
                </div>
              ))}
            </div>

            {/* Main Content */}
            <div className="flex-1 p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-[#F4F6FF] font-semibold">Today&apos;s Tasks</h3>
                <span className="text-xs text-[#A6AFC8]">4 items</span>
              </div>

              {/* Task List */}
              <div className="space-y-3">
                {taskItems.map((task, index) => (
                  <div
                    key={task.title}
                    className={`flex items-center justify-between p-4 rounded-xl bg-white/[0.03] border border-white/5 hover:border-[#4C6EF5]/30 transition-all duration-500 group ${
                      isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                    }`}
                    style={{ transitionDelay: `${0.4 + index * 0.1}s` }}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                        task.status === 'completed' 
                          ? 'bg-[#4C6EF5]' 
                          : task.status === 'in-progress'
                          ? 'border-2 border-[#4C6EF5]'
                          : 'border-2 border-white/20'
                      }`}>
                        {task.status === 'completed' && <CheckCircle2 size={12} className="text-white" />}
                      </div>
                      <span className={`text-sm ${
                        task.status === 'completed' 
                          ? 'text-[#A6AFC8] line-through' 
                          : 'text-[#F4F6FF]'
                      }`}>
                        {task.title}
                      </span>
                    </div>
                    <span className={`text-xs ${
                      task.status === 'in-progress' 
                        ? 'text-[#4C6EF5]' 
                        : 'text-[#A6AFC8]'
                    }`}>
                      {task.time}
                    </span>
                  </div>
                ))}
              </div>

              {/* Bottom Tagline */}
              <div className="mt-6 pt-4 border-t border-white/5">
                <p className="text-xs text-[#A6AFC8] text-center">
                  Isaac drafts. You approve.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DashboardSection;
