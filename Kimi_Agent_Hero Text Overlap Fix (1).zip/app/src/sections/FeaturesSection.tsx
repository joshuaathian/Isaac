import { useEffect, useRef, useState } from 'react';
import { Calendar, FileSearch, MessageSquare, ArrowRight } from 'lucide-react';

const features = [
  {
    icon: Calendar,
    title: 'Scheduling & Operations',
    bullets: [
      'Calendar that protects focus time',
      'Smart rescheduling & buffers',
      'Prep briefs before every meeting'
    ]
  },
  {
    icon: FileSearch,
    title: 'Research & Briefs',
    bullets: [
      'Competitor & market snapshots',
      'Summaries with sources attached',
      'Action items highlighted'
    ]
  },
  {
    icon: MessageSquare,
    title: 'Comms & Follow-up',
    bullets: [
      'Draft emails in your voice',
      'Meeting recaps within minutes',
      'Reminders tied to outcomes'
    ]
  }
];

const FeaturesSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="features"
      className="section-pinned flex items-center z-20"
    >
      <div className="relative w-full h-full px-[7vw]">
        {/* Section Title */}
        <h2 
          className={`text-[clamp(32px,3.6vw,52px)] font-bold text-[#F4F6FF] absolute transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
          }`}
          style={{ 
            top: '12vh',
            fontFamily: 'Sora, sans-serif'
          }}
        >
          What Isaac handles
        </h2>

        {/* Cards Container */}
        <div 
          className="absolute flex gap-[3vw]"
          style={{ 
            top: '30vh',
            left: '7vw',
            right: '7vw'
          }}
        >
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className={`glass-card p-8 flex flex-col transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-16'
              }`}
              style={{ 
                width: '28vw',
                height: '52vh',
                minWidth: '280px',
                transitionDelay: `${0.2 + index * 0.15}s`,
                animation: isVisible ? `float 4s ease-in-out infinite ${index * 1.3}s` : 'none'
              }}
            >
              {/* Icon */}
              <div className="w-12 h-12 rounded-xl bg-[#4C6EF5]/10 flex items-center justify-center mb-6">
                <feature.icon size={24} className="text-[#4C6EF5]" />
              </div>

              {/* Title */}
              <h3 
                className="text-xl font-semibold text-[#F4F6FF] mb-6"
                style={{ fontFamily: 'Sora, sans-serif' }}
              >
                {feature.title}
              </h3>

              {/* Bullets */}
              <ul className="flex-1 space-y-4">
                {feature.bullets.map((bullet, i) => (
                  <li key={i} className="flex items-start gap-3 text-[#A6AFC8]">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#4C6EF5] mt-2 flex-shrink-0" />
                    <span className="text-sm leading-relaxed">{bullet}</span>
                  </li>
                ))}
              </ul>

              {/* Learn More Link */}
              <button className="flex items-center gap-2 text-sm text-[#4C6EF5] hover:text-[#5c7cf7] transition-colors mt-6 group">
                Learn more
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
