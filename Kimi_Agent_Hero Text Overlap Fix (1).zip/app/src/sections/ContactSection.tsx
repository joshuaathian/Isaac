import { useState, useEffect, useRef } from 'react';
import { ArrowRight, MessageCircle, Send } from 'lucide-react';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({ name: '', email: '', company: '', message: '' });
    }, 1500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section 
      ref={sectionRef}
      id="contact"
      className="relative z-[90] py-24 lg:py-32"
    >
      <div className="px-6 lg:px-[7vw]">
        {/* Headline Block */}
        <div className={`text-center mb-16 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <h2 
            className="text-[clamp(36px,4vw,64px)] font-bold text-[#F4F6FF] mb-6"
            style={{ fontFamily: 'Sora, sans-serif' }}
          >
            Ready to meet Isaac?
          </h2>
          <p className="text-[#A6AFC8] text-lg mb-8">
            Start free. No credit card required.
          </p>
          <div className="flex items-center justify-center gap-4">
            <button className="btn-primary flex items-center gap-2">
              Start free trial
              <ArrowRight size={18} />
            </button>
            <button className="btn-secondary flex items-center gap-2">
              <MessageCircle size={18} />
              Talk to sales
            </button>
          </div>
        </div>

        {/* Contact Form */}
        <div 
          className={`max-w-2xl mx-auto transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
          style={{ transitionDelay: '0.2s' }}
        >
          <div className="glass-card p-8">
            <h3 
              className="text-xl font-bold text-[#F4F6FF] mb-6 text-center"
              style={{ fontFamily: 'Sora, sans-serif' }}
            >
              Send us a message
            </h3>

            {submitted ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 rounded-full bg-[#4C6EF5]/20 flex items-center justify-center mx-auto mb-4">
                  <Send size={28} className="text-[#4C6EF5]" />
                </div>
                <h4 className="text-[#F4F6FF] font-semibold text-lg mb-2">Message sent!</h4>
                <p className="text-[#A6AFC8]">We&apos;ll get back to you within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm text-[#A6AFC8] mb-2">Name</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-[#F4F6FF] placeholder-[#A6AFC8]/50 focus:border-[#4C6EF5]/50 focus:outline-none transition-colors"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-[#A6AFC8] mb-2">Email</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-[#F4F6FF] placeholder-[#A6AFC8]/50 focus:border-[#4C6EF5]/50 focus:outline-none transition-colors"
                      placeholder="you@company.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-[#A6AFC8] mb-2">Company</label>
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-[#F4F6FF] placeholder-[#A6AFC8]/50 focus:border-[#4C6EF5]/50 focus:outline-none transition-colors"
                    placeholder="Your company"
                  />
                </div>

                <div>
                  <label className="block text-sm text-[#A6AFC8] mb-2">Message</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-[#F4F6FF] placeholder-[#A6AFC8]/50 focus:border-[#4C6EF5]/50 focus:outline-none transition-colors resize-none"
                    placeholder="How can we help?"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full btn-primary flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      Send message
                      <Send size={18} />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-24 pt-8 border-t border-white/5">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <span 
                className="text-xl font-bold text-[#F4F6FF]"
                style={{ fontFamily: 'Sora, sans-serif' }}
              >
                Isaac
              </span>
            </div>
            
            <div className="flex items-center gap-6">
              <button className="text-sm text-[#A6AFC8] hover:text-[#F4F6FF] transition-colors">
                Privacy
              </button>
              <button className="text-sm text-[#A6AFC8] hover:text-[#F4F6FF] transition-colors">
                Terms
              </button>
              <button className="text-sm text-[#A6AFC8] hover:text-[#F4F6FF] transition-colors">
                Security
              </button>
            </div>
            
            <p className="text-sm text-[#A6AFC8]">
              © {new Date().getFullYear()} Isaac Systems
            </p>
          </div>
        </footer>
      </div>
    </section>
  );
};

export default ContactSection;
