import { useEffect, useRef, useState } from 'react';
import { Play, ArrowRight } from 'lucide-react';

const HeroSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Trigger entrance animation after mount
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      ref={sectionRef}
      id="hero"
      className="section-pinned flex items-center justify-center z-10"
    >
      <div className="relative w-full h-full flex flex-col items-center justify-center px-6">
        {/* Eyebrow */}
        <span 
          className={`font-mono-label text-[#A6AFC8] mb-8 absolute transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
          }`}
          style={{ top: '14vh', transitionDelay: '0.1s' }}
        >
          AI Agent for Teams
        </span>

        {/* Eye Motif */}
        <div 
          className={`relative eye-glow transition-all duration-1000 ${
            isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
          }`}
          style={{ 
            width: 'min(34vw, 420px)',
            position: 'absolute',
            top: '46vh',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            transitionDelay: '0.2s'
          }}
        >
          <svg viewBox="0 0 200 200" className="w-full h-full">
            {/* Outer ring */}
            <circle 
              cx="100" 
              cy="100" 
              r="95" 
              fill="none" 
              stroke="rgba(244, 246, 255, 0.15)" 
              strokeWidth="1"
            />
            {/* Inner ring (rotating) */}
            <g className="animate-rotate-slow" style={{ transformOrigin: 'center' }}>
              <circle 
                cx="100" 
                cy="100" 
                r="75" 
                fill="none" 
                stroke="rgba(76, 110, 245, 0.4)" 
                strokeWidth="1.5"
                strokeDasharray="20 10 5 10"
              />
            </g>
            {/* Iris */}
            <circle 
              cx="100" 
              cy="100" 
              r="45" 
              fill="none" 
              stroke="rgba(76, 110, 245, 0.6)" 
              strokeWidth="2"
            />
            {/* Pupil */}
            <circle 
              cx="100" 
              cy="100" 
              r="18" 
              fill="#4C6EF5"
              className="animate-pulse-glow"
            />
            {/* Center dot */}
            <circle 
              cx="100" 
              cy="100" 
              r="6" 
              fill="#F4F6FF"
            />
            {/* Glow effect behind */}
            <defs>
              <radialGradient id="eyeGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="rgba(76, 110, 245, 0.3)" />
                <stop offset="100%" stopColor="rgba(76, 110, 245, 0)" />
              </radialGradient>
            </defs>
            <circle cx="100" cy="100" r="120" fill="url(#eyeGlow)" />
          </svg>
        </div>

        {/* Headline */}
        <h1 
          className={`text-[clamp(32px,4.5vw,64px)] font-bold text-[#F4F6FF] text-center absolute transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ 
            top: '62vh',
            maxWidth: '60vw',
            fontFamily: 'Sora, sans-serif',
            transitionDelay: '0.4s',
            lineHeight: 1.1
          }}
        >
          Your business, running itself.
        </h1>

        {/* Subheadline */}
        <p 
          className={`text-[clamp(14px,1.3vw,18px)] text-[#A6AFC8] text-center absolute leading-relaxed transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
          style={{ 
            top: '74vh',
            maxWidth: '50vw',
            transitionDelay: '0.5s'
          }}
        >
          Isaac is an AI agent that schedules, researches, and communicates—so your team stays focused on what matters.
        </p>

        {/* CTA Buttons */}
        <div 
          className={`flex items-center gap-4 absolute transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
          }`}
          style={{ top: '84vh', transitionDelay: '0.6s' }}
        >
          <button onClick={scrollToContact} className="btn-primary flex items-center gap-2">
            Start free trial
            <ArrowRight size={18} />
          </button>
          <button className="btn-secondary flex items-center gap-2">
            <Play size={18} />
            Watch a 2-min demo
          </button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
