import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Check, Sparkles } from 'lucide-react';

const workflowSteps = [
  'Turn requests into briefs in seconds',
  'Sources included, claims verified',
  'Follow-ups scheduled automatically'
];

const chatMessages = [
  {
    type: 'user',
    content: 'Prep a competitive snapshot for our pricing call.',
    time: '10:23 AM'
  },
  {
    type: 'isaac',
    content: 'On it. I\'ll pull positioning, recent news, and three talking points.',
    time: '10:23 AM'
  },
  {
    type: 'isaac',
    content: 'Here\'s the brief. Want me to add a one-pager?',
    time: '10:24 AM'
  }
];

const WorkflowSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="workflow"
      className="section-pinned flex items-center z-40"
    >
      <div className="relative w-full h-full">
        {/* Left Panel */}
        <div 
          className={`absolute transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
          }`}
          style={{ 
            left: '7vw',
            top: '18vh',
            width: '34vw'
          }}
        >
          {/* Eyebrow */}
          <span className="font-mono-label text-[#4C6EF5] mb-4 block">
            Request → Output
          </span>

          {/* Headline */}
          <h2 
            className="text-[clamp(28px,3.2vw,48px)] font-bold text-[#F4F6FF] mb-6 leading-tight"
            style={{ fontFamily: 'Sora, sans-serif' }}
          >
            Ask once. Get a ready-to-send brief.
          </h2>

          {/* Description */}
          <p className="text-[#A6AFC8] text-lg leading-relaxed mb-8">
            Describe what you need. Isaac researches, structures, and delivers—so you walk into every meeting prepared.
          </p>

          {/* Steps */}
          <ul className="space-y-4 mb-8">
            {workflowSteps.map((step, index) => (
              <li key={index} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-[#4C6EF5]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check size={12} className="text-[#4C6EF5]" />
                </div>
                <span className="text-[#F4F6FF] text-sm">{step}</span>
              </li>
            ))}
          </ul>

          {/* CTA */}
          <button className="btn-primary flex items-center gap-2">
            Try a sample request
            <ArrowRight size={18} />
          </button>
        </div>

        {/* Right Panel - Chat Card */}
        <div 
          className={`glass-card absolute overflow-hidden transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-16'
          }`}
          style={{ 
            left: '46vw',
            top: '16vh',
            width: '47vw',
            height: '70vh',
            minWidth: '380px',
            transitionDelay: '0.2s'
          }}
        >
          {/* Chat Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#4C6EF5] to-[#3b5ce5] flex items-center justify-center">
                <Sparkles size={18} className="text-white" />
              </div>
              <div>
                <span className="text-[#F4F6FF] font-medium block">Isaac</span>
                <span className="text-xs text-[#A6AFC8]">AI Assistant</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              <span className="text-xs text-[#A6AFC8]">Online</span>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="p-6 space-y-4 h-[calc(100%-140px)] overflow-y-auto">
            {chatMessages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'} transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                }`}
                style={{ transitionDelay: `${0.4 + index * 0.1}s` }}
              >
                <div 
                  className={`max-w-[80%] p-4 rounded-2xl ${
                    message.type === 'user' 
                      ? 'bg-[#4C6EF5] text-white rounded-br-md' 
                      : 'bg-white/5 text-[#F4F6FF] rounded-bl-md border border-white/10'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{message.content}</p>
                  <span className={`text-xs mt-2 block ${
                    message.type === 'user' ? 'text-white/60' : 'text-[#A6AFC8]'
                  }`}>
                    {message.time}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/5 bg-[#0B1022]/80">
            <div className="flex items-center gap-3">
              <div className="flex-1 px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-[#A6AFC8]">
                Type a message...
              </div>
              <button className="w-10 h-10 rounded-xl bg-[#4C6EF5] flex items-center justify-center hover:bg-[#5c7cf7] transition-colors">
                <ArrowRight size={18} className="text-white" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WorkflowSection;
