import { useState, useEffect, useRef } from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: 'What can Isaac actually do?',
    answer: 'Isaac is an AI agent that handles scheduling, research, and communications for your team. It can prepare meeting briefs, reschedule appointments, draft emails, conduct competitive research, and send follow-ups—all while maintaining your voice and preferences.'
  },
  {
    question: 'How does Isaac access my calendar?',
    answer: 'Isaac connects to your calendar through secure OAuth authentication. You grant specific permissions, and Isaac can only access what you allow. We support Google Calendar, Outlook, and most major calendar providers.'
  },
  {
    question: 'Can I review everything before it\'s sent?',
    answer: 'Absolutely. Isaac operates in draft mode by default. Every email, brief, or communication is prepared for your review before sending. You can approve, edit, or decline any action Isaac suggests.'
  },
  {
    question: 'What integrations are supported?',
    answer: 'Isaac integrates with Google Workspace, Microsoft 365, Slack, Salesforce, HubSpot, Notion, and many more. We\'re constantly adding new integrations based on customer feedback.'
  },
  {
    question: 'Is my data used to train AI models?',
    answer: 'No. Your data is never used to train our AI models. We have a strict data policy that ensures your information remains private and is only used to provide you with the Isaac service.'
  },
  {
    question: 'How do I invite my team?',
    answer: 'You can invite team members directly from the Isaac dashboard. Simply enter their email addresses, and they\'ll receive an invitation to join your workspace. Team plans include collaboration features and shared settings.'
  }
];

const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [visibleItems, setVisibleItems] = useState<boolean[]>(new Array(faqs.length).fill(false));
  const itemsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observers: IntersectionObserver[] = [];

    itemsRef.current.forEach((item, index) => {
      if (item) {
        const observer = new IntersectionObserver(
          ([entry]) => {
            if (entry.isIntersecting) {
              setVisibleItems(prev => {
                const newState = [...prev];
                newState[index] = true;
                return newState;
              });
              observer.disconnect();
            }
          },
          { threshold: 0.2 }
        );
        observer.observe(item);
        observers.push(observer);
      }
    });

    return () => observers.forEach(obs => obs.disconnect());
  }, []);

  const toggleItem = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section 
      id="faq"
      className="relative z-[80] py-24 lg:py-32"
    >
      <div className="px-6 lg:px-[7vw]">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 
            className="text-[clamp(32px,3.6vw,52px)] font-bold text-[#F4F6FF]"
            style={{ fontFamily: 'Sora, sans-serif' }}
          >
            Questions & answers
          </h2>
        </div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              ref={el => { itemsRef.current[index] = el; }}
              className={`glass-card overflow-hidden transition-all duration-700 ${
                visibleItems[index] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
              style={{ transitionDelay: `${index * 0.08}s` }}
            >
              <button
                onClick={() => toggleItem(index)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-white/[0.02] transition-colors"
              >
                <span 
                  className="text-[#F4F6FF] font-medium pr-4"
                  style={{ fontFamily: 'Sora, sans-serif' }}
                >
                  {faq.question}
                </span>
                <ChevronDown 
                  size={20} 
                  className={`text-[#A6AFC8] flex-shrink-0 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              
              <div 
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-6 pb-6">
                  <p className="text-[#A6AFC8] leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="text-center mt-12">
          <p className="text-[#A6AFC8] mb-4">Still have questions?</p>
          <button 
            onClick={() => {
              const element = document.querySelector('#contact');
              if (element) element.scrollIntoView({ behavior: 'smooth' });
            }}
            className="text-[#4C6EF5] hover:underline"
          >
            Get in touch
          </button>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
