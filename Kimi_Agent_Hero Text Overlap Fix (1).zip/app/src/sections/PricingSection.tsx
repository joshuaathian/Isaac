import { useState, useEffect, useRef } from 'react';
import { Check, Sparkles, Building2, Zap } from 'lucide-react';

const plans = [
  {
    name: 'Starter',
    icon: Zap,
    price: { monthly: 0, annual: 0 },
    description: 'Core scheduling + briefs',
    features: [
      'Smart calendar management',
      'Meeting briefs',
      'Basic research',
      'Email drafts (10/month)',
      '7-day history'
    ],
    cta: 'Get started free',
    highlighted: false
  },
  {
    name: 'Team',
    icon: Sparkles,
    price: { monthly: 29, annual: 23 },
    description: 'Advanced research + comms',
    features: [
      'Everything in Starter',
      'Unlimited email drafts',
      'Advanced research',
      'Meeting recaps',
      'Team collaboration',
      '90-day history',
      'Priority support'
    ],
    cta: 'Start free trial',
    highlighted: true
  },
  {
    name: 'Business',
    icon: Building2,
    price: { monthly: null, annual: null },
    description: 'SSO + compliance + dedicated support',
    features: [
      'Everything in Team',
      'SSO & SCIM',
      'Advanced security',
      'Audit logs',
      'Custom integrations',
      'Unlimited history',
      'Dedicated success manager',
      'SLA guarantee'
    ],
    cta: 'Contact sales',
    highlighted: false
  }
];

const PricingSection = () => {
  const [isAnnual, setIsAnnual] = useState(true);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="pricing"
      className="relative z-[70] py-24 lg:py-32"
    >
      <div className="px-6 lg:px-[7vw]">
        {/* Header */}
        <div className={`text-center mb-12 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <h2 
            className="text-[clamp(32px,3.6vw,52px)] font-bold text-[#F4F6FF] mb-6"
            style={{ fontFamily: 'Sora, sans-serif' }}
          >
            Simple pricing
          </h2>
          
          {/* Toggle */}
          <div className="flex items-center justify-center gap-4">
            <span className={`text-sm ${!isAnnual ? 'text-[#F4F6FF]' : 'text-[#A6AFC8]'}`}>
              Monthly
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className="relative w-14 h-7 rounded-full bg-white/10 transition-colors"
            >
              <div 
                className={`absolute top-1 w-5 h-5 rounded-full bg-[#4C6EF5] transition-all duration-300 ${
                  isAnnual ? 'left-8' : 'left-1'
                }`}
              />
            </button>
            <span className={`text-sm ${isAnnual ? 'text-[#F4F6FF]' : 'text-[#A6AFC8]'}`}>
              Annual
            </span>
            <span className="ml-2 px-2 py-0.5 rounded-full bg-[#4C6EF5]/20 text-[#4C6EF5] text-xs">
              Save 20%
            </span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={plan.name}
              className={`glass-card p-8 flex flex-col transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              } ${plan.highlighted ? 'border-[#4C6EF5]/50 relative' : ''}`}
              style={{ transitionDelay: `${0.2 + index * 0.1}s` }}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="px-3 py-1 rounded-full bg-[#4C6EF5] text-white text-xs font-medium">
                    Most popular
                  </span>
                </div>
              )}

              {/* Plan Header */}
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  plan.highlighted ? 'bg-[#4C6EF5]/20' : 'bg-white/5'
                }`}>
                  <plan.icon size={20} className={plan.highlighted ? 'text-[#4C6EF5]' : 'text-[#A6AFC8]'} />
                </div>
                <h3 
                  className="text-xl font-bold text-[#F4F6FF]"
                  style={{ fontFamily: 'Sora, sans-serif' }}
                >
                  {plan.name}
                </h3>
              </div>

              {/* Price */}
              <div className="mb-4">
                {plan.price.monthly !== null ? (
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-[#F4F6FF]">
                      ${isAnnual ? plan.price.annual : plan.price.monthly}
                    </span>
                    <span className="text-[#A6AFC8]">/user/mo</span>
                  </div>
                ) : (
                  <div className="text-4xl font-bold text-[#F4F6FF]">Custom</div>
                )}
                <p className="text-sm text-[#A6AFC8] mt-1">{plan.description}</p>
              </div>

              {/* Features */}
              <ul className="flex-1 space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#4C6EF5]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Check size={12} className="text-[#4C6EF5]" />
                    </div>
                    <span className="text-sm text-[#A6AFC8]">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <button 
                className={`w-full py-3 rounded-xl font-medium transition-all duration-300 ${
                  plan.highlighted 
                    ? 'btn-primary' 
                    : 'btn-secondary'
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>

        {/* Bottom Note */}
        <p className="text-center text-sm text-[#A6AFC8] mt-12">
          All plans include a 14-day free trial. No credit card required.
        </p>
      </div>
    </section>
  );
};

export default PricingSection;
