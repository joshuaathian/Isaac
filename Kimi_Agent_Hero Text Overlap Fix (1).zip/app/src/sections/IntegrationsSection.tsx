import { useEffect, useRef, useState } from 'react';
import { 
  Calendar, 
  Mail, 
  MessageSquare, 
  FileText, 
  Database,
  FolderOpen,
  Building2
} from 'lucide-react';

const integrations = [
  { icon: Calendar, name: 'Google Calendar', category: 'Calendar', capability: 'Schedule sync' },
  { icon: Mail, name: 'Outlook', category: 'Calendar', capability: 'Email & calendar' },
  { icon: MessageSquare, name: 'Slack', category: 'Comms', capability: 'Notifications' },
  { icon: Mail, name: 'Email', category: 'Comms', capability: 'Draft & send' },
  { icon: FolderOpen, name: 'Google Drive', category: 'Files', capability: 'File access' },
  { icon: FileText, name: 'Notion', category: 'Files', capability: 'Notes & docs' },
  { icon: Database, name: 'Salesforce', category: 'CRM', capability: 'Contact sync' },
  { icon: Building2, name: 'HubSpot', category: 'CRM', capability: 'Deal tracking' },
];

const IntegrationsSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="integrations"
      className="section-pinned flex items-center z-[60]"
    >
      <div className="relative w-full h-full flex flex-col items-center">
        {/* Header */}
        <div 
          className={`text-center absolute transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-8'
          }`}
          style={{ top: '12vh' }}
        >
          <h2 
            className="text-[clamp(32px,3.6vw,52px)] font-bold text-[#F4F6FF] mb-4"
            style={{ fontFamily: 'Sora, sans-serif' }}
          >
            Connects to the tools you already use
          </h2>
          <p className="text-[#A6AFC8] text-lg max-w-2xl mx-auto">
            Calendar, email, files, and CRM—connected without complex setup.
          </p>
        </div>

        {/* Integration Grid */}
        <div 
          className={`glass-card absolute p-8 transition-all duration-700 ${
            isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
          }`}
          style={{ 
            top: '32vh',
            left: '10vw',
            right: '10vw',
            maxWidth: '1000px',
            margin: '0 auto',
            transitionDelay: '0.2s'
          }}
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {integrations.map((integration, index) => (
              <div
                key={integration.name}
                className={`group p-5 rounded-xl bg-white/[0.03] border border-white/5 hover:border-[#4C6EF5]/30 hover:bg-white/[0.06] transition-all duration-300 cursor-pointer ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                }`}
                style={{ transitionDelay: `${0.3 + index * 0.05}s` }}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-lg bg-[#4C6EF5]/10 flex items-center justify-center group-hover:bg-[#4C6EF5]/20 transition-colors">
                    <integration.icon size={20} className="text-[#4C6EF5]" />
                  </div>
                </div>
                <h4 className="text-[#F4F6FF] font-medium text-sm mb-1">
                  {integration.name}
                </h4>
                <p className="text-[#A6AFC8] text-xs">
                  {integration.capability}
                </p>
              </div>
            ))}
          </div>

          {/* Bottom Note */}
          <div className="mt-6 pt-6 border-t border-white/5 text-center">
            <p className="text-sm text-[#A6AFC8]">
              And more integrations coming soon.{' '}
              <button className="text-[#4C6EF5] hover:underline">
                Request an integration
              </button>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IntegrationsSection;
