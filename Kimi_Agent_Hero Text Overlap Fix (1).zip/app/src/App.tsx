import Navigation from './sections/Navigation';
import HeroSection from './sections/HeroSection';
import FeaturesSection from './sections/FeaturesSection';
import DashboardSection from './sections/DashboardSection';
import WorkflowSection from './sections/WorkflowSection';
import SecuritySection from './sections/SecuritySection';
import IntegrationsSection from './sections/IntegrationsSection';
import PricingSection from './sections/PricingSection';
import FAQSection from './sections/FAQSection';
import ContactSection from './sections/ContactSection';

function App() {
  return (
    <div className="relative">
      {/* Background */}
      <img 
        src="/city-bg.jpg" 
        alt="" 
        className="city-bg"
      />
      <div className="bg-gradient-overlay" />
      
      {/* Grain overlay */}
      <div className="grain-overlay" />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Sections */}
      <main className="relative">
        <HeroSection />
        <FeaturesSection />
        <DashboardSection />
        <WorkflowSection />
        <SecuritySection />
        <IntegrationsSection />
        <PricingSection />
        <FAQSection />
        <ContactSection />
      </main>
    </div>
  );
}

export default App;
